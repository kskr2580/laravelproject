<footer class="site-footer">
    <div class="footer-inner bg-white">
        <div class="row">
            <div class="col-sm-6">
                Copyright &copy; 2018 Oushud kino
            </div>
            <div class="col-sm-6 text-right">
                Designed by <a href="#">faysal</a>
            </div>
        </div>
    </div>
</footer>
