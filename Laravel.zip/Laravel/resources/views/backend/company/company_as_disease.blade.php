<h1>hello</h1>
@php
  $disease = App\Company::find(2);
  echo $disease->company_name;
@endphp
